<div class="container travel_footer mb-3 ">
    <div class="row">
        <div class="col-md-4 center">

            <header>
                <h4 class="fa fa-2x fa-info circled">
                    Info
                </h4>
            </header>

            <ul class="divided ">
                <li>
                    <a href="/site/1-chi-siamo.html">CHI SIAMO</a>
                </li>

                <li>
                    <a href="/contatti/1-info.html">CONTATTACI</a>
                </li>

                <li>
                    <a href="/site/2-come-funziona">COME FUNZIONA</a>
                </li>

                <li>
                    <a href="/contatti/1-info.html">SUGGERIMENTI</a>
                </li>

                <li>
                    <a href="/site/disclaimer">DISCLAIMER</a>
                </li>


            </ul>
        </div>

        <!-- Posts -->
        <div class="col-md-4 center">
            <header>
                <h4 class="fa fa-2x fa-globe circled">
                    Travel Blogger
                </h4>
            </header>
            <ul class="divided ">

                <li>
                    <a href="#">20 Travel Blogger</a>
                </li>

                <li>
                    <a href="#">400 Posti visitati</a>
                </li>

                <li>
                    <a href="#">Filosofia dei Travel Blogger</a>
                </li>

                <li>
                    <a href="#">Perchè i Travel Blogger</a>
                </li>

                <li>
                    <a href="#">Diventa Travel Blogger</a>
                </li>
                <li>
                    <a href="/blog/">BLOG</a>
                </li>



            </ul>
        </div>

        <div class="col-md-4 center">
            <header>
                <h4 class="fa fa-2x fa-camera circled">
                    Info contenuti
                </h4>
            </header>

            <ul class="icons">
                <li><a href="#" class="fa fa-twitter">  Twitter </a></li>
                <li><a href="https://www.facebook.com/fyltravel/" class="fa fa-facebook">  Facebook </a></li>
                <li><a href="#" class="fa fa-instagram"> Instagram </a></li>
                <li><a href="#" class="fa fa-pinterest"> Pinterest </a></li>
            </ul>

        </div>

    </div>
</div>