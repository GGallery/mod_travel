<div class="">

    <fb:login-button
            scope="public_profile,email"
            onlogin="checkLoginState();">
    </fb:login-button>
    <div id="status"></div>


</div>